import typing

import arcpy


def setup_env(path: typing.Optional[str] = None) -> None:
    """Nastavení workspace pro práci."""
    if path is None:
        arcpy.env.workspace = "C:/Users/cah0021/Projekty/PGIS3/data"
    else:
        workspace_path = f"C:/Users/cah0021/Projekty/PGIS3/data/{path}"
        arcpy.env.workspace = workspace_path
        exist = arcpy.Exists(arcpy.env.workspace)
        if not exist:
            raise ValueError(f"Workspace path {workspace_path} does not exist!")
    arcpy.env.overwriteOutput = True


def is_projected(crs: arcpy.SpatialReference) -> bool:
    return crs.type == "Projected"
