from .context_managers import LayerContextManager, LayerFromDatasetContextManager, BandAsArrayContextManager
from .data import data_countries, data_shaded_relief
from .paths import PathManager
